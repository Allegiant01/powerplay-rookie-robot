package org.firstinspires.ftc.teamcode;

import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_TO_POSITION;
import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_USING_ENCODER;
import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.STOP_AND_RESET_ENCODER;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@Autonomous
public class RookieAuto extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        double clawOffset = 0;    // Servo mid position
        final double CLAW_SPEED = 0.02;   // sets rate to move servo

        DcMotor fLeftMotor = hardwareMap.get(DcMotor.class, "front_left_motor");
        DcMotor fRightMotor = hardwareMap.get(DcMotor.class, "front_right_motor");
        DcMotor bLeftMotor = hardwareMap.get(DcMotor.class, "back_left_motor");
        DcMotor bRightMotor = hardwareMap.get(DcMotor.class, "back_right_motor");
        Servo claw = hardwareMap.get(Servo.class, "clamp_servo");
        DcMotor linearSlide = hardwareMap.get(DcMotor.class, "left_intake");
        DcMotor linearSlide2 = hardwareMap.get(DcMotor.class, "right_intake");

        linearSlide.setDirection(DcMotor.Direction.REVERSE);
        linearSlide2.setDirection(DcMotor.Direction.REVERSE);
        fRightMotor.setDirection(DcMotor.Direction.REVERSE);

        linearSlide.setMode(STOP_AND_RESET_ENCODER);
        linearSlide2.setMode(STOP_AND_RESET_ENCODER);

        linearSlide.setMode(RUN_USING_ENCODER);
        linearSlide2.setMode(RUN_USING_ENCODER);
        fRightMotor.setMode(RUN_USING_ENCODER);
        fLeftMotor.setMode(RUN_USING_ENCODER);
        bLeftMotor.setMode(RUN_USING_ENCODER);
        bRightMotor.setMode(RUN_USING_ENCODER);

        BNO055IMU imu = hardwareMap.get(BNO055IMU.class, "imu");
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit = BNO055IMU.AngleUnit.DEGREES;
        imu.initialize(parameters);

        while(!imu.isGyroCalibrated() && !isStopRequested()) {
            Thread.sleep(1);
            telemetry.addData("Calibrating IMU...", imu.isGyroCalibrated());
            telemetry.update();
        }
        telemetry.addData("IMU Calibrated", imu.isGyroCalibrated());
        telemetry.update();

        waitForStart();
        while (opModeIsActive()) {
            //1in = 62 ticks
            //Above is good for drivetrain
            double ticksPerRevolution = 1440;
            double wheelCircumference = 1.41731 * Math.PI;
            double ticksPerInch = 62;
            double encoderTickCtPerRot = wheelCircumference * ticksPerInch;

            telemetry.addData("Slide 1 Encoder", linearSlide.getCurrentPosition());
            telemetry.addData("Slide 2 Encoder", linearSlide2.getCurrentPosition());
            linearSlide.setTargetPosition(1500);
            linearSlide2.setTargetPosition(1500);
            linearSlide.setPower(0.7);
            linearSlide2.setPower(0.7);
            linearSlide.setMode(RUN_TO_POSITION);
            linearSlide2.setMode(RUN_TO_POSITION);

            linearSlide.setTargetPosition(0);
            linearSlide2.setTargetPosition(0);
            linearSlide.setPower(0.7);
            linearSlide2.setPower(0.7);
            linearSlide.setMode(RUN_TO_POSITION);
            linearSlide2.setMode(RUN_TO_POSITION);

        }
    }
}
